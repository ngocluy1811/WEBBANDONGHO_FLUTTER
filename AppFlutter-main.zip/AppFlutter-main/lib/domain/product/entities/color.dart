
class ProductColorEntity {

  final String title;
  final List<int> rgb;

  ProductColorEntity({
    required this.title,
    required this.rgb,
  });

}
