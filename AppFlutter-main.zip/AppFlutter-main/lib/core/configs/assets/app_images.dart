class AppImages {

  static const basePath = 'assets/images/';
  static const profile = '${basePath}profile.png';
  static const orderPlaced = '${basePath}order_placed.png';
}