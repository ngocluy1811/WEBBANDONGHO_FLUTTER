class AppUrl {

  static const storageBase = 'https://firebasestorage.googleapis.com/v0/b/ecommerce-e354a.firebasestorage.app/o/';
  static const categoryImage = '${storageBase}Categories%2Fimages%2F';
  static const productImage = '${storageBase}Products%2Fimages%2F';
  static const alt = '?alt=media';

}